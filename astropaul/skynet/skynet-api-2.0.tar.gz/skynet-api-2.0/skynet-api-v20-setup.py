#!/usr/bin/env python

"""
SkyNet API distutils setup script
"""

from __future__ import absolute_import, division, print_function

from distutils.core import setup

try:
    # Allow building wheels with distutils
    from wheel.bdist_wheel import bdist_wheel
except ImportError:
    bdist_wheel = None

api_ver = (2, 0)

api_strver = 'v{:d}{:d}'.format(*api_ver)

root_package = 'skynet.api.{}'.format(api_strver)
script_package = root_package + '.sample_scripts'

setup(
    name='skynet-api',
    version='{:d}.{:d}'.format(*api_ver),
    description='SkyNet Python API',
    long_description='SkyNet API is a means to programmatically control the '
                     'SkyNet website by sending HTTP requests to '
                     'https://api.skynet.unc.edu in order to submit or '
                     'update optical and radio observations, check their '
                     'status, download the data, and administer SkyNet.',
    author='Vladimir Kouprianov, Joshua Haislip',
    author_email='v.kouprianov@gmail.com, jhaislip@gmail.com',
    url='www.skynet.unc.edu',
    license='open-source',
    platforms='any',
    requires=['marshmallow', 'requests'],
    packages=[root_package + '.methods', script_package],
    py_modules=['skynet', 'skynet.api', root_package] +
        [root_package + '.' + name
         for name in ('client', 'errors', 'orm', 'serializers')],
    package_data={script_package: ['sn_manager.targets']},
    cmdclass={'bdist_wheel': bdist_wheel},
    options={
        'bdist_wininst': {'user_access_control': 'auto'},
        'bdist_wheel': {'universal': True},
    },
    script_name='skynet-api-{}-setup.py'.format(api_strver),
)
