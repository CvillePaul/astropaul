"""
SkyNet API: procedural Python interface methods for specific requests
"""
