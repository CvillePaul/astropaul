"""
Skynet API sample and testing scripts
"""
